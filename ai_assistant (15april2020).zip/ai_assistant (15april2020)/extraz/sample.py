from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.feature_extraction.text import CountVectorizer
from keras import models, layers 
from keras.utils import to_categorical
import re, json, random
import numpy as np
import pandas as pd
example = []
labels = []
text = []
data = {}
classes = {}
text_vectors = []

file = open('nlu.md')
for line in file:
    if '##' in line and not 'lookup' in line:
        line = re.sub(r'[\W]','',line)
        intent_data = line.replace('intent', '')
    elif not '##' in line and not 'txt' in line and line.replace('\n', ''):
        line = re.sub(r'[\d]','',line)
        text_data = line.replace('- ', '').replace('\n', '')
        data = {"intent": intent_data,
            "text": text_data}                 
        example.append(data)  
 
for x in example:
    labels.append(x['intent'])
    text.append(x['text'])
print(labels)



y_train = []
y_test = []
X_train = []
X_test = []
tt = []

vectorizer = CountVectorizer()
count = vectorizer.fit(text)

for indx,line in enumerate(text):
    #print(line)
    x = vectorizer.transform([line])
    text_vectors.append(x.toarray()[0])
    if indx%5 ==0:
        X_test.append(x.toarray()[0])
        y_test.append(labels[indx])
    else:
        X_train.append(x.toarray()[0])
        y_train.append(labels[indx])
"""
for line in text:
    x = vectorizer.transform([line])
    text_vectors.append(x.toarray()[0])


data = {'Text':text_vectors,
        'Labels':labels}
df = pd.DataFrame(data)
X = df['Text']
y = df['Labels']

while True:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3)
    if not set(y_train) - set(y_test):
        break
   
X_train_vectors = []
for x in X_train:
    X_train_vectors.append(x)
X_test_vectors = []
for x in X_test:
    X_test_vectors.append(x)
"""
vectors = np.asarray(text_vectors)
v = np.asarray(X_train)
u = np.asarray(X_test)

list_labels, unique_label  = pd.factorize(labels)
list_labels  = to_categorical(list_labels)
list_labels_train, unique_label_train  = pd.factorize(y_train)
list_labels_train = to_categorical(list_labels_train)
list_labels_test, unique_label_test = pd.factorize(y_test) 
list_labels_test = to_categorical(list_labels_test)


i = 0    
for x in unique_label:
    classes.update({i : x})
    i += 1

model = models.Sequential()
model.add(layers.Dense(units = 100,activation='relu',input_shape = vectors[0].shape))
model.add(layers.Dense(units = 100,activation='relu'))
model.add(layers.Dense(units = 17,activation='softmax'))

print(v.shape)
print(vectors[0].shape)

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
classifier = model.fit(v, list_labels_train, epochs=20, batch_size=8)

loss, acc  = model.evaluate(u, list_labels_test)
print("loss      :", loss)
print("accuracy  :", acc)

print("class labels-----------")
print(classes)
test = []
input = ["no way", "hi", "hey", "who are you?", "no","hello"]
for line in input:

    print("input          :", line)
    t = vectorizer.transform([line])
    test.append(t.toarray()[0])
"""
#test_data_array = np.asarray(test)
pred = model.predict(test_data_array) 
pred = np.argmax(pred, axis = 1)[:6]  
label = np.argmax(list_labels_test,axis = 1)[:10] 
print(pred) 
print(label)

print("predicted label:", classes[pred[0]]) 
"""
countt = 0
for i in range(6):
    print(input[i])
    for x in example:
        if x['text'] in input[i]:
            actual = x['intent']
            print("Actual label:", actual)
            break
    prediction = model.predict(np.asarray([test[i]]))
    predicted_label = classes[np.argmax(prediction[0])]
    
    #print(test_files_names.iloc[i])
    #print('Actual label:' + test_tags.iloc[i])
    print("Predicted label: ", predicted_label)
    if actual == predicted_label:
        countt += 1
print(countt)   
print(countt/6*100)


"""
prediction1 = model.predict(test_data_array)
#print(prediction1)

sorting = (-prediction1).argsort()

# getting the top 2 predictions
sorted_ = sorting[0][:5]

for value in sorted_:
    # you can get your classes from the encoder(your_classes = encoder.classes_) 
    # or from a dictionary that you created before.
    # And then we access them with the predicted index.
    predicted_label = classes[value]
    # just some rounding steps
    prob = (prediction1[0][value]) * 100
    prob = "%.2f" % round(prob,2)
    print("I have %s%% sure that it belongs to %s." % (prob, predicted_label))


pred = model.predict(u) 
pred = np.argmax(pred, axis = 1)[:6] 
label = np.argmax(list_labels_test,axis = 1)[:6] 

print(pred) 
print(label)

"""
