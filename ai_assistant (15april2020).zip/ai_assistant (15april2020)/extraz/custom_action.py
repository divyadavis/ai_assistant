class Conversion:

    def _init_(self):
        self.precedence = {"-":1, "+":1, "*":2, "/":2 }
        self.stack = []
        self.top = -1
        

