import typing, json
from typing import Any, Optional, Text, Dict, List, Type
from rasa.nlu.components import Component
from rasa.nlu.config import RasaNLUModelConfig
from rasa.nlu.training_data import Message, TrainingData
from rasa.nlu.constants import (
    ENTITIES_ATTRIBUTE
)
if typing.TYPE_CHECKING:
    from rasa.nlu.model import Metadata
from duckling import Duckling

duck     = Duckling()
duck.load()



class MyComponent(Component):
    def __init__(self, component_config: Optional[Dict[Text, Any]] = None) -> None:
        super().__init__(component_config)

    def train(
        self,
        training_data: TrainingData,
        config: Optional[RasaNLUModelConfig] = None,
        **kwargs: Any,
    ) -> None:
        print("Train this component....................................")
        
        pass

    def process(self, message: Message, **kwargs: Any) -> None:
        print("Process an incoming message.....................................")
       
        message.text = message.text.lower()
        
        #print("msgggg.............", message.text)
        
        print(duck.parse(message.text))
        
        
        
        
        for x in duck.parse(message.text):
        
            if x['dim'] == 'number' and not x['body'].isdigit():
                
            
                message.text = message.text.replace(str(x['body']), str((x['value'])['value']))
                
        
        message.text = message.text.replace("+", " add ").replace("-", " subtract ").replace("*", " multiply ").replace("/", " divide ").replace("(", " left ").replace(")", " right ")
        #print("msgggg.............", message.text)
        
        pass



    def persist(self, file_name: Text, model_dir: Text) -> Optional[Dict[Text, Any]]:
        print("Persist this component to disk for future loading.................")

        pass


