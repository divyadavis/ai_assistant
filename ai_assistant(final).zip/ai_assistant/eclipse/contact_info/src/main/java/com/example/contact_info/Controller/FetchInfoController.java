package com.example.contact_info.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.contact_info.Contact_Model.contactModel;
import com.example.contact_info.Model.Model;
import com.example.contact_info.Service.Service;

@RestController
public class FetchInfoController {

	@Autowired
	 Service service;
	
	
	@GetMapping(value = "/fetch_contact_info")
	public List<contactModel> getAllContact_info() {
		return service.findAllContact_info();
	}

	@GetMapping(value = "/fetch_project_info")
	public List<Model> getAllProject_info() {
		return service.findAllProject_info();
	}
}