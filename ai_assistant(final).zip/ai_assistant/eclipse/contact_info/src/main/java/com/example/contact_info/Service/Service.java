package com.example.contact_info.Service;

import java.util.List;

import com.example.contact_info.Contact_Model.contactModel;
import com.example.contact_info.Model.Model;

public interface Service {


	List<contactModel> findAllContact_info();
	
	List<Model> findAllProject_info();

	
}
