package com.example.contact_info.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.contact_info.Contact_Model.contactModel;
import com.example.contact_info.Model.Model;
@Repository
public class FetchRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<contactModel> findAllContact_info() {
		List<contactModel> list = jdbcTemplate.query("SELECT * FROM Contacts_info", new RowMapper<contactModel>() {

			@Override
			public contactModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				contactModel emp = new contactModel();

				emp.setContact_id(rs.getInt("contact_id"));
				emp.setF_name(rs.getString("f_name"));
				emp.setL_name(rs.getString("l_name"));
				emp.setContact_number(rs.getString("contact_number"));
				emp.setEmail(rs.getString("email"));

				return emp;
			}

		});

		return list;
	}

	public List<Model> findAllProject_info() {
		List<Model> project = jdbcTemplate.query("SELECT * FROM project_info", new RowMapper<Model>() {

			@Override
			public Model mapRow(ResultSet rs, int rowNum) throws SQLException {
				Model pro = new Model();

				pro.setProject_id(rs.getInt("project_id"));
				pro.setProject_name(rs.getString("project_name"));
				pro.setDomain(rs.getString("domain"));
				pro.setTechnology(rs.getString("technology"));

				return pro;
			}

		});

		return project;
}
}