package com.example.contact_info.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.contact_info.Contact_Model.contactModel;
import com.example.contact_info.Model.Model;
import com.example.contact_info.Repository.FetchRepository;
@org.springframework.stereotype.Service
public  class ServiceImpl implements Service {

	@Autowired
	 FetchRepository repo;
	
	


	@Override
	public List<contactModel> findAllContact_info() {
		// TODO Auto-generated method stub
		return repo.findAllContact_info();
	}




	@Override
	public List<Model> findAllProject_info() {
		// TODO Auto-generated method stub
		return repo.findAllProject_info();
	}

}
