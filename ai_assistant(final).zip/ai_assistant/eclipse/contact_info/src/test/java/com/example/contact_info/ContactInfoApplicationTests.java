package com.example.contact_info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
