CREATE DATABASE demo;
SHOW DATABASES;
CREATE  TABLE IF NOT EXISTS `demo`.`Contacts` (
  `contact_id` INT  AUTO_INCREMENT ,
  `name` VARCHAR(150) NOT NULL ,
  `contact_number` VARCHAR(75) ,
  `email` VARCHAR(255) ,
  PRIMARY KEY (`contact_id`) )
  ENGINE = InnoDB;
CREATE  TABLE IF NOT EXISTS `demo`.`Contacts_info` (
  `contact_id` INT  AUTO_INCREMENT ,
  `f_name` VARCHAR(150) NOT NULL ,
  `l_name` VARCHAR(150) NOT NULL ,
  `contact_number` LONG ,
  `email` VARCHAR(255) ,
  PRIMARY KEY (`contact_id`) )
  ENGINE = InnoDB;
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("vijay","sunkeswari",9945216638,"vijay.sunkeswari@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("jinesh","sumedhan",9611988550,"jinesh.sumedhan@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("sanjeev","chandrasekaran",9500722177,"sanjeev.chandrasekaran@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("thillai","rajan",9945216638,"thillai.rajan@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("bhakti","mohapatra",7608052923,"bhakti.mohapatra@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("devendra","singh",8147389230,"devendra.singh@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("chelsa","charles",9447088019,"chelsa.charlse@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("divya","davis",9562722353,"divya.davis@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("sona","shaju",9048646046,"sona.shaju@tarento.com");
INSERT INTO Contacts_info(f_name,l_name,contact_number,email) VALUES ("aswin","pradeep",9945216638,"aswin.pradeep@tarento.com");

SELECT * FROM demo.Contacts_info;
UPDATE Contacts SET name = "vijay" WHERE contact_id = 1;
UPDATE Contacts SET name = "sanjeev" WHERE contact_id = 2;
UPDATE Contacts SET name = "jinesh" WHERE contact_id = 3;
UPDATE Contacts SET name = "bhakti" WHERE contact_id = 4;
UPDATE Contacts SET name = "thillai" WHERE contact_id = 5;
UPDATE Contacts SET name = "devendra" WHERE contact_id = 6;
UPDATE Contacts SET name = "chelsa" WHERE contact_id = 7;
UPDATE Contacts SET name = "divya" WHERE contact_id = 8;
UPDATE Contacts SET name = "aswin" WHERE contact_id = 9;
UPDATE project_info SET technology = "android" WHERE project_id = 5;

SELECT * FROM project_info;

INSERT INTO project_info(project_name,domain,technology) VALUES ("EkStep","education","angular");
INSERT INTO project_info(project_name,domain,technology) VALUES ("Anuvad","government","react");
INSERT INTO project_info(project_name,domain,technology) VALUES ("KLAY Schools Web - AD","education","ai");
INSERT INTO project_info(project_name,domain,technology) VALUES ("Lithium-Emergency-System","transportation","ai");
INSERT INTO project_info(project_name,domain,technology) VALUES ("KAL - Ayusante","healthcare","ai");
INSERT INTO project_info(project_name,domain,technology) VALUES ("Swedbank-AM","banking and finance","spring");
INSERT INTO project_info(project_name,domain,technology) VALUES ("Finance","banking and finance","angular");
INSERT INTO project_info(project_name,domain,technology) VALUES ("KAL - Academy - US","healthcare","angular");
INSERT INTO project_info(project_name,domain,technology) VALUES ("KAL - Ayurvedagram","social","spring");
INSERT INTO project_info(project_name,domain,technology) VALUES ("KAL - My Ayurveda","social","java");