## greet user
* greet
  - utter_greet

## say goodbye
* goodbye
  - utter_goodbye

# fetch_contact
* contact
  - action_contact

# weather
* weather
  - action_weather

# location
* location
  - utter_location

# thanks
* thanks
  - utter_thanks


# calculations
* calculation
  - action_calculation

# project_info
* domain_info
  - action_domain

# project_info
* skills
  - action_technology


## bot challenge
* bot_challenge
  - utter_iamabot

# police_museum
* police_museum
  - utter_police_museum

# cell_inventor
* cell_inventor
  - utter_cell_inventor

# finn_independence
* finn_independence
  - utter_finn_independence

# moon_lander
* moon_lander
  - utter_moon_lander

# grand_central_terminal
* grand_central_terminal
  - utter_grand_central_terminal

# potato_founder
* potato_founder
  - utter_potato_founder

# fire_temple
* fire_temple
  - utter_fire_temple

# first_cricket
* first_cricket
  - utter_first_cricket

# prime_minister
* prime_minister
  - utter_prime_minister

# days_in_week
* days_in_week
  - utter_days_in_week

# indian_national_animal
* indian_national_animal
  - utter_indian_national_animal

# smallest_country
* smallest_country
  - utter_smallest_country

# largest_statue
* largest_statue
  - utter_largest_statue


# wikipedia_information
* wiki_info
  - action_information






